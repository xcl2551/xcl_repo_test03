var sysConfig = {
    xcApiUrlPre: '/api',
    xcApiUrl: 'http://api.xuecheng.com/',
    imgUrl:'http://img.xuecheng.com/',
    videoUrl:'http://video.xuecheng.com/',
    openAuthenticate:true,
    openAuthorize:true
}

module.exports = sysConfig
